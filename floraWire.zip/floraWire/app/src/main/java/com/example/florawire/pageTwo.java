package com.example.florawire;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

public class pageTwo extends AppCompatActivity {

    TextView home_bg, homePage;

    ImageView GridBox, ImageFlower;

    Button MusicSettings_btn, levels_btn;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_page_two);
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });

        home_bg = findViewById(R.id.home_bg);
        homePage =findViewById(R.id.homePage);

        GridBox = findViewById(R.id.GridBox);
        ImageFlower = findViewById(R.id.ImageFlower);

        levels_btn = findViewById(R.id.levels_btn);
        MusicSettings_btn = findViewById(R.id.MusicSettings_btn);

        levels_btn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(pageTwo.this, pageThree.class);
                startActivity(intent);

                Toast.makeText(getApplicationContext(), "Level's Page", Toast.LENGTH_SHORT).show();

            }
        });

    }
}