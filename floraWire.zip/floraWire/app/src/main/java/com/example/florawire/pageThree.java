package com.example.florawire;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

public class pageThree extends AppCompatActivity {
    TextView levelsBg, levelPage;

    ImageView GridBox, ImageFlower;

    Button easy_btn, hard_btn;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_page_three);
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });

        levelsBg = findViewById(R.id.levelsBg);
        levelPage = findViewById(R.id.levelPage);

        GridBox = findViewById(R.id.GridBox);
        ImageFlower = findViewById(R.id.ImageFlower);

        easy_btn = findViewById(R.id.easy_btn);
        hard_btn = findViewById(R.id.hard_btn);

        easy_btn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(pageThree.this, pageFour.class);
                startActivity(intent);

                Toast.makeText(getApplicationContext(), "Easy Level", Toast.LENGTH_SHORT).show();

            }
        });

        hard_btn.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(pageThree.this, pageFive.class);
                Toast.makeText(getApplicationContext(), "Hard Level", Toast.LENGTH_SHORT).show();
                startActivity(intent);

            }
        });

        ImageView button_previous = findViewById(R.id.previous_btn);

        button_previous.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(pageThree.this, pageTwo.class);
                startActivity(intent);
            }
        });
    }
}